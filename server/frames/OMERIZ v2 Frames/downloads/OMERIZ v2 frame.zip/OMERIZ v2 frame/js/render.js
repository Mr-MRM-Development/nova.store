const { ipcRenderer } = require("electron");

ipcRenderer.on("themes", (event, data)=>{
    if(data.mode === "dark") {
        document.getElementById("themesLink").href = "css/themes/dark.css";
    } else {
        document.getElementById("themesLink").href = "css/themes/light.css";
    }
})