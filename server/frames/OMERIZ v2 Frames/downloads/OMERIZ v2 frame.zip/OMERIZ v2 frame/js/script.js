function setTitleText(text) {
    document.querySelector(".title-bar .title-text").textContent = text;
}

setTitleText(document.querySelector("head title").textContent);